package phase11;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class UserManager {
    private List<User> users = new ArrayList<>();
    private User loggedInUser = null;
    private final String filePath = "user1.txt"; // Path to the file where user data will be stored

    public UserManager() {
        loadUsersFromFile(); // Load users when the application starts
    }

    // Create a new user with email address
    public boolean createUser(String username, String password, String email, List<String> roles) {
        if (findUser(username) != null) { // Check if username is already taken
            System.out.println("Username already taken.");
            return false;
        }

        // Create new user and assign roles
        User newUser = new User(username, password, email);
        for (String role : roles) {
            newUser.addRole(role); // Add all roles provided during registration
        }
        users.add(newUser); // Add user to the list
        saveUsersToFile(); // Save the new user to the file after creation
        System.out.println("New user created with username: " + username + ", email: " + email + ", and roles: " + roles);
        return true;
    }

    // Log in using username and password
    public boolean login(String username, String password) {
        User user = findUser(username);
        if (user != null && user.getPassword().equals(password)) {
            loggedInUser = user;
            return true;
        }
        return false;
    }

    // OTP generation for resetting password
    public void generateOtpForUser(String username) {
        User user = findUser(username);
        if (user != null) {
            String otp = generateOtp();
            Date expiration = new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)); // OTP valid for 5 minutes
            user.setOtp(otp, expiration);
            System.out.println("Generated OTP for user " + username + ": " + otp + " (valid for 5 minutes)");
        } else {
            System.out.println("User not found.");
        }
    }

    // Generate a 6-digit random OTP
    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Random 6-digit number
        return String.valueOf(otp);
    }

    // Validate OTP for login or password reset
    public boolean validateOtpForUser(String username, String enteredOtp) {
        User user = findUser(username);
        if (user != null && user.isOtpValid(enteredOtp)) {
            System.out.println("OTP is valid for user " + username);
            loggedInUser = user; // Set logged-in user if OTP is valid
            return true;
        } else {
            System.out.println("Invalid or expired OTP.");
            return false;
        }
    }

    // Log in using OTP
    public boolean loginWithOtp(String username, String enteredOtp) {
        return validateOtpForUser(username, enteredOtp);
    }

    // Admin resets a user account with a new OTP
    public boolean resetUserAccount(String username) {
        User user = findUser(username);
        if (user != null) {
            String otp = generateOtp();
            Date expiration = new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)); // OTP valid for 5 minutes
            user.setOtp(otp, expiration);
            saveUsersToFile();
            System.out.println("User account reset. OTP: " + otp);
            return true;
        }
        return false;
    }

    // Admin deletes a user
    public boolean deleteUser(String username) {
        User user = findUser(username);
        if (user != null) {
            users.remove(user);
            saveUsersToFile();
            System.out.println("Deleted user: " + username);
            return true;
        }
        return false;
    }

    // Admin adds a role to a user
    public boolean addRoleToUser(String username, String role) {
        User user = findUser(username);
        if (user != null) {
            user.addRole(role);
            saveUsersToFile();
            System.out.println("Role added: " + role + " for user: " + username);
            return true;
        }
        return false;
    }

    // Admin removes a role from a user
    public boolean removeRoleFromUser(String username, String role) {
        User user = findUser(username);
        if (user != null) {
            user.removeRole(role);
            saveUsersToFile();
            System.out.println("Role removed: " + role + " for user: " + username);
            return true;
        }
        return false;
    }

    // Admin lists all users with their roles
    public void listUsers() {
        for (User user : users) {
            System.out.println("Username: " + user.getUsername() + ", Email: " + user.getEmail() + ", Roles: " + user.getRoles());
        }
    }

    // Save users to a file (including email address)
    private void saveUsersToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            for (User user : users) {
                writer.println(user.getUsername() + "," + user.getPassword() + "," + user.getEmail() + "," + String.join(";", user.getRoles()));
            }
        } catch (IOException e) {
            System.out.println("Error saving users to file: " + e.getMessage());
        }
    }

    // Load users from a file
    private void loadUsersFromFile() {
        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("No user data found. Starting with an empty user list.");
            return; // No user1.txt file yet, so start with an empty list
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 4) {
                    System.out.println("Skipping invalid user data: " + line);
                    continue;
                }
                String username = parts[0];
                String password = parts[1];
                String email = parts[2];
                String[] rolesArray = parts[3].split(";");
                User user = new User(username, password, email);
                for (String role : rolesArray) {
                    user.addRole(role);
                }
                users.add(user); // Add loaded user to the list
            }
        } catch (IOException e) {
            System.out.println("Error loading users from file: " + e.getMessage());
        }
    }

    // Find user by username
    public User findUser(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public User getLoggedInUser() {
        return loggedInUser;
    }

    public void logout() {
        loggedInUser = null;
    }
}
